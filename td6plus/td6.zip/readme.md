# TP5: technologies du web

## Objectifs:
***principalement, les objectifs de ce tp sont:***
- Manipulation des SESSIONS

## Attentes
- Ce qui n'a pas été fait: les questions facultatives
- Ce qui a été fait:
  les questions non facultatives
