<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head>
    <meta charset="UTF-8"/>
    <title>Déconnexion</title>
  </head>
<body><p> Vous êtes déconnecté </p>
<p><a href=".">Retour à la page principale</a></p>
</body>
</html>
