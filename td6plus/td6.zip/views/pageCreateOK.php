<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
  <head>
    <meta charset="UTF-8"/>
    <title>Création d'utilisateur</title>
</head>
<body>

<p>Le compte a été créé</p>
<p><a href="index.php">Connectez-vous</a></p>
</body>
</html>
