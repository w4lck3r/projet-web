  <?php
  class ParmsException extends Exception {}
  ?>
