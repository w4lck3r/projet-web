<?php
 require_once('etc/dsn_filename.php');
 $data = new DataLayer(DSN_FILENAME);
?>
