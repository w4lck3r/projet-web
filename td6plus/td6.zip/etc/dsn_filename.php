<?php
const DSN_FILENAME = __DIR__.'/webtp_dsn.txt';
?>
